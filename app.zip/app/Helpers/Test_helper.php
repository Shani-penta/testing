<?php 
function randomString() {
    return substr(str_shuffle('jdsfhksjdbhfhbvffdshbfhreiuhfrkhgkjnb'),10,10);
}