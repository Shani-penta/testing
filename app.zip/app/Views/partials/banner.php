<div class="baner-slider">
			<div class="flexslider left">
				<ul class="slides">
					<li>
						<img src="<?= base_url(); ?>/public/assets/images/baner1.jpg" alt="baner">
						<div class="meta">
							<h1>Al Roumi</h1>
							<h2>Serving the industry since year 1990</h2>
						</div>
					</li>
					<li>
						<img src="<?= base_url(); ?>/public/assets/images/baner2.jpg" alt="baner">
						<div class="meta">
							<h1>Al Roumi</h1>
							<h2>One of the biggest oil & gas field supply & services company</h2>
						</div>
					</li>
					<li>
						<img src="<?= base_url(); ?>/public/assets/images/baner3.jpg" alt="baner">
						<div class="meta">
							<h1>Al Roumi</h1>
							<h2>Representing global brands in the Emirates of Abu Dhabi</h2>
						</div>
					</li>
					<li>
						<img src="<?= base_url(); ?>/public/assets/images/baner4.jpg" alt="baner">
						<div class="meta">
							<h1>Al Roumi</h1>
							<h2>ADNOC ICV certified</h2>
							<div class="icv">
								<img src="<?= base_url(); ?>/public/assets/images/icv.jpg" alt="">
							</div>
						</div>
					</li>
					<li>
						<img src="<?= base_url(); ?>/public/assets/images/baner5.jpg" alt="baner">
						<div class="meta">
							<h1>Al Roumi</h1>
							<h2>ISO certified Company</h2>
						</div>
					</li>
				</ul>
			</div>
		</div>