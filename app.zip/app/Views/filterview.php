<html>
<head>
<title></title>
</head>
<body>
<h1>{mytitle|upper}</h1>
<p></p>
<h2>{content}</h2>


</body>
</html>