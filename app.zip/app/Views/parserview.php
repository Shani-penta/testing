<html>
<head>
<title></title>
</head>
<body>
<h1>{mytitle}</h1>
<p></p>
<h2>Details</h2>
{sub_lists}
<h1>{subject}</h1>
<p>{abbr}</p>
{/sub_lists}

</body>
</html>